package com.campus.recruitment.service;

import com.campus.recruitment.model.AppointmentModel;

public interface AppointmentService {
	public boolean isAddAppointment(AppointmentModel model,String filename);
}
